# RN7 1-Click Tool  
Debloat • Clean • Game Mode • Ultra Battery  
**Safe & No Root (Termux + Shizuku)**

Made with ❤️ by **myrul.dev**  
🔗 https://www.facebook.com/xamrl  

---

## ✨ Fitur Utama
- ✅ Debloat MIUI Aman (disable only, tidak uninstall)
- 🧹 Clean System (kill background + trim cache)
- 🎮 Game Mode ON / OFF
- 🔋 Ultra-Hemat Baterai Mode
- 📊 Monitor RAM & CPU real-time
- 🔁 Restore penuh (jika ingin balik ke kondisi awal)
- 📱 Auto-detect device (Redmi / Xiaomi / POCO)
- ❌ Tanpa root
- ⚠️ Aman untuk daily use

---

## 📱 Perangkat yang Didukung
- Redmi / Xiaomi / POCO (MIUI)
- Android 10 – 14
- Tested di Redmi Note 7

---

## 🧰 Persyaratan
1. Termux (F-Droid)  
   https://f-droid.org/packages/com.termux/

2. Shizuku  
   https://play.google.com/store/apps/details?id=moe.shizuku.privileged.api

3. Shizuku status: RUNNING  
4. rish sudah terpasang (`rish -c id` harus tembus)

---

## 🚀 Instalasi
```bash
chmod +x rn7_1klik.sh
./rn7_1klik.sh
```

---

## 🧭 Menu & Fungsi
1. Debloat aman (iklan & telemetry MIUI)  
2. Debloat + optional  
3. Clean system  
4. Game Mode ON  
5. Game Mode OFF  
6. Ultra Battery Mode ON  
7. Ultra Battery Mode OFF  
8. Monitor RAM / CPU  
9. Restore semua perubahan  
0. Keluar  

---

## 🔋 Ultra Battery Mode
- Matikan master sync
- Tekan background service
- Hemat baterai maksimal
Gunakan OFF untuk restore.

---

## 🛡️ Keamanan
✔️ Tidak uninstall sistem  
✔️ Tidak root  
✔️ Bisa restore  
❌ Tidak unlock bootloader

---

## 📜 Lisensi
MIT License

---

Made with **myrul.dev**  
https://www.facebook.com/xamrl
